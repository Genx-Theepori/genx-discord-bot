require("dotenv").config();
const {
  Client,
  GatewayIntentBits,
  MessageAttachment,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require("discord.js");
const fs = require('fs');
const { createCanvas, loadImage } = require("canvas");

module.exports = async client => {
  client.on('interactionCreate', async interaction => {
    if (interaction.isButton()) {
      if (interaction.customId === "ap_apply") {
        // Create and show the application modal
        const modal = new ModalBuilder()
          .setTitle("Whitelist Applications")
          .setCustomId("application_modal");

        const inputs = [
          { id: "ap_username", label: "Enter your real name", placeholder: "Enter your real name" },
          { id: "ap_userage", label: "Enter your Age", placeholder: "Enter your Age" },
          { id: "ap_useringameName", label: "Ingame Character Name", placeholder: "Your name" },
          { id: "ap_useremail", label: "Email", placeholder: 'gmail@gmail.com' },
          { id: "ap_userexp", label: "Did you read the rules and regulations?", placeholder: "yes/no" }
        ];

        inputs.forEach(input => {
          const textInput = new TextInputBuilder()
            .setCustomId(input.id)
            .setLabel(input.label)
            .setMinLength(2)
            .setMaxLength(25)
            .setRequired(true)
            .setPlaceholder(input.placeholder)
            .setStyle(TextInputStyle.Short);
          
          modal.addComponents(new ActionRowBuilder().addComponents(textInput));
        });

        try {
          await interaction.showModal(modal);
        } catch (error) {
          console.error("Error Showing Modals:", error);
        }
        console.log(`Whitelist button clicked by: ${interaction.user.username}`);
      } else if (interaction.customId === "ap_pending") {
        // Handle pending application
        const embed = new EmbedBuilder(interaction.message.embeds[0]).setColor("#FFEB3B");

        await interaction.message.edit({
          content: `Pending done by <@${interaction.user.id}>`,
          embeds: [embed],
          components: []
        });

        const memberId = embed.data.footer.text; // Get the user ID from footer
        const member = interaction.guild.members.cache.get(memberId);
        const channel = interaction.guild.channels.cache.get(process.env.PendingChannel);

        // Create a pending ticket image
        const enquiryCode = embed.data.fields[0].value;

        // Load the image for the ticket
        try {
          const pendingImage = await loadImage('https://i.ibb.co/RcLcHyG/KCRP-ticket-Pending-copy.png');
          const canvas = createCanvas(1440, 576);
          const ctx = canvas.getContext('2d');

          ctx.drawImage(pendingImage, 0, 0);
          
          ctx.font = "35px sans-serif";
          ctx.fillStyle = "black";

          // Get current date and format it
          const currentDate = new Date();
          const formattedDate = `${currentDate.getDate()}/${currentDate.getMonth() + 1}/${currentDate.getFullYear()} ${currentDate.getHours()}:${String(currentDate.getMinutes()).padStart(2, '0')}`;

          ctx.fillText(member.user.username.toUpperCase(), 200, 450);
          ctx.fillText(`Date: ${formattedDate}`, 200, 500); // Add date to the image

          const imageBuffer = canvas.toBuffer("image/png");
          
          const attachment = new AttachmentBuilder(imageBuffer, { name: "ticket.png" });
          
          await member.roles.add(process.env.PendingRole);
          await channel.send({
            content: `<@${member.user.id}> Visit <#${process.env.waitingchannel}> TO COMPLETE THE PROCEDURE.`,
            files: [attachment]
          });
          
          await member.send({
            content: `<@${member.user.id}> Visit <#${process.env.waitingchannel}> TO COMPLETE THE PROCEDURE.`,
            files: [attachment]
          });
        } catch (error) {
          console.error("Error creating ticket image:", error);
        }
      } else if (interaction.customId === "ap_reject") {
        // Show rejection reason modal
        const rejectModal = new ModalBuilder()
            .setTitle("Whitelist Applications Reject")
            .setCustomId("reject_reason_modal");

        const rejectReasonInput = new TextInputBuilder()
            .setCustomId('ap_reject_reason')
            .setLabel("What is the reason for rejection?")
            .setMinLength(5)
            .setMaxLength(50)
            .setRequired(true)
            .setPlaceholder("Enter rejection details")
            .setStyle(TextInputStyle.Short);

        rejectModal.addComponents(new ActionRowBuilder().addComponents(rejectReasonInput));

        try {
            await interaction.showModal(rejectModal);
        } catch (error) {
            console.error("Error showing Reject Modal:", error);
        }
      }
    } else if (interaction.isModalSubmit()) {
      if (interaction.customId === "application_modal") {
        
        // Retrieve input values
        let username = interaction.fields.getTextInputValue("ap_username");
        let age = interaction.fields.getTextInputValue("ap_userage");
        let ingameName = interaction.fields.getTextInputValue("ap_useringameName");
        let email = interaction.fields.getTextInputValue("ap_useremail");
        let rulesRead = interaction.fields.getTextInputValue('ap_userexp');

         // Log channel
         let logChannel = interaction.guild.channels.cache.get(process.env.LogChannel);
         
         if (!logChannel) return;

         // Create buttons for admin actions
         let actionButtons = new ActionRowBuilder().addComponents([
             new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId("ap_pending").setLabel("Pending").setEmoji('⌛'),
             new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId('ap_reject').setLabel("Reject").setEmoji('❌')
         ]);

         // Read from Database.json to get the next enquiry ID
         let databaseContent;
         try {
           databaseContent = fs.readFileSync("Database.json", 'utf8');
         } catch (error) {
           console.error("Error reading Database.json:", error);
           return;
         }

         let databaseJson;
         try {
           databaseJson = JSON.parse(databaseContent);
         } catch (error) {
           console.error("Error parsing Database.json:", error);
           return;
         }

         let enquiryID = databaseJson.id;

         // Send application log to the log channel
         logChannel.send({
           content: `Whitelist Application From <@${interaction.user.id}> \n<@&${process.env.adminrole1}> <@&${process.env.adminrole2}>`,
           embeds: [
             new EmbedBuilder()
               .setColor("#FFEB3B")
               .addFields([
                 { name: "Enquiry ID", value: `\`\`\`${enquiryID}\`\`\``, inline: false },
                 { name: "Real Name", value: `\`\`\`${username}\`\`\``, inline: false },
                 { name: "Age", value: `\`\`\`${age}\`\`\``, inline: false },
                 { name: "Ingame Character Name", value: `\`\`\`${ingameName}\`\`\``, inline: false },
                 { name: "Email", value: `\`\`\`${email}\`\`\``, inline: false },
                 { name: "Rules Read", value: `\`\`\`${rulesRead}\`\`\``, inline: false }
               ])
               .setFooter({ text: `${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
           ],
           components: [actionButtons]
         });

         // Acknowledge the application submission
         await interaction.reply({
           content: `Thank you for your application with code **#${enquiryID}**! We'll review it and be in touch.`,
           ephemeral: true
         });

         // Update the enquiry ID in Database.json
         databaseJson.id += 1;
         fs.writeFileSync("Database.json", JSON.stringify(databaseJson));

         // Notify user of application receipt
         await interaction.user.send({
           content: "Thank you for your whitelist application. We'll review it and be in touch.",
           embeds: [
             new EmbedBuilder()
               .setAuthor({ name: process.env.ServerName, iconURL: process.env.ServerLogo })
               .setColor('#FFEB3B')
               .addFields([
                 { name: "Message", value: "```Thank you for applying! We will respond shortly.```", inline: true },
                 { name: "Enquiry ID?", value: `\`\`\`${enquiryID}\`\`\``, inline: false }
               ])
               .setFooter({ text: process.env.ServerName })
           ]
         }).catch(() => {});
      } else if (interaction.customId === "reject_reason_modal") {

         // Handle rejection reason submission
         let rejectReason = interaction.fields.getTextInputValue("ap_reject_reason");
         
         let embedMessageEdit;
         
         try {
           embedMessageEdit = new EmbedBuilder(interaction.message.embeds[0]).setColor("Red");
           
           await interaction.message.edit({
             embeds: [embedMessageEdit],
             components: []
           });
           
           let rejectedMemberID = embedMessageEdit.data.footer.text; // Get user ID from footer
           let rejectedMember = interaction.guild.members.cache.get(rejectedMemberID);

           try {
             await rejectedMember.send(`Your ${process.env.ServerName} whitelist application has been rejected by ${interaction.user.tag}. Reason: ${rejectReason}`);
           } catch (error) {
             if (error.code === 50007) { // User has DMs disabled
               await interaction.reply({
                 content: "The mentioned user has blocked their DMs. Don't worry, the role has been added.",
                 ephemeral: true
               });
             } else {
               await interaction.reply({
                 content: "An error occurred while processing your request.",
                 ephemeral: true
               });
             }
           }

           let rejectChannel = interaction.guild.channels.cache.get(process.env.RejectChannel);

           const rejectionEmbed = new EmbedBuilder()
             .setColor('#FFEB3B')
             .addField(`❌ <@${rejectedMember.user.id}> Your application was rejected. Feel free to reapply after reading the rules.\nREASON:` , rejectReason);

           await rejectChannel.send({
             content: `<@${rejectedMember.user.id}> YOUR WHITELIST WAS REJECTED.`,
             embeds:[rejectionEmbed]
           });

           await rejectedMember.send({
             content:`<@${rejectedMember.user.id}> YOUR WHITELIST WAS REJECTED.`,
             embeds:[rejectionEmbed]
           });
           
         } catch (error) {
           console.error('Error handling rejection:', error);
         }
      }
    }
  });
};